/* ==========================================================================
   Play & Learn with Bip — Interactive Environment Diorama & Zero-Lag Audio
   Domain: https://bipthebot.net | YouTube/IG/TikTok: @playlearnwithbip
   ========================================================================== */

const EPISODES = [
  { id: "LCwZiT2EIik", icon: "🟣", title: "Who's Cracking the Purple Egg? Dino Eggs #2", meta: "2:20 • Mystery Dino Eggs" },
  { id: "9T2d1-nPPbQ", icon: "🥚", title: "What's Hatching Inside? Dino Eggs #1", meta: "2:51 • Mystery Dino Eggs" },
  { id: "g6gomczRjYw", icon: "🧼", title: "Dirty Big Trucks at Bip's Magic Car Wash!", meta: "7:07 • Magic Car Wash" },
  { id: "CtmFQDcpvgY", icon: "🚜", title: "Muddy Farm Tractors & Barn Animals!", meta: "8:46 • Vehicles & Farm" },
  { id: "sDwtEwIJ6zs", icon: "🔤", title: "Learn the Alphabet A to Z with Bip!", meta: "12:30 • Full A–Z Phonics" },
  { id: "bLw6DOlg-Pw", icon: "🐮", title: "Peekaboo Cow & Dolphin! Find the Animals", meta: "2:48 • Hide & Seek" },
  { id: "XhWwEkmjUak", icon: "🦁", title: "Who Is Hiding at the Zoo? 15 Animals", meta: "8:04 • Safari & Zoo" },
  { id: "A44kkwUljMM", icon: "🐳", title: "What's Swimming Under the Water? Ocean & Pond", meta: "8:05 • Water Worlds" },
  { id: "Fp5KZCXMpjs", icon: "🦊", title: "Woodland Forest Animals: Fox, Owl & Beaver", meta: "1:40 • Forest Habitat" },
  { id: "FG-Prg_mWaU", icon: "🐸", title: "Bip Visits the Pond! Frog, Duck & Muskrat", meta: "1:32 • Pond Habitat" },
  { id: "Bg_6uIAVhV8", icon: "🐴", title: "Farm Barn Animals: Horse, Hen & Goat", meta: "1:53 • Cozy Barn" },
  { id: "T9vdmRaVw4o", icon: "🐧", title: "Polar Ice Animals: Penguin & Polar Bear", meta: "1:33 • Polar Ice" }
];

const HABITATS = {
  forest: {
    name: "🌲 Woodland Forest",
    episodeId: "Fp5KZCXMpjs",
    intro: "Welcome to the sunlit woodland forest! Tap an animal among the pine trees and stream!",
    items: [
      { id: "fox", emoji: "🦊", label: "Red Fox", x: 24, y: 66, sfx: "chime", line: "Ooh, a Red Fox! Red foxes have fluffy orange tails to stay warm in cozy forest dens!" },
      { id: "owl", emoji: "🦉", label: "Wise Owl", x: 74, y: 28, sfx: "hoot", line: "Hoo, hoo! That's a Forest Owl! Owls perch high in pine trees and see in the starry night!" },
      { id: "beaver", emoji: "🦫", label: "Busy Beaver", x: 54, y: 74, sfx: "splash", line: "Look, a Busy Beaver! Beavers build neat wooden lodges across forest streams and slap their flat tails!" },
      { id: "deer", emoji: "🦌", label: "Spotted Deer", x: 80, y: 64, sfx: "chime", line: "Hi, gentle Woodland Deer! Deer leap softly over mossy logs and nibble sweet green leaves!" }
    ]
  },
  pond: {
    name: "🪷 Freshwater Pond",
    episodeId: "FG-Prg_mWaU",
    intro: "Splash! We're at the peaceful lily-pad pond! Tap a pond friend in the water!",
    items: [
      { id: "frog", emoji: "🐸", label: "Green Frog", x: 26, y: 68, sfx: "pop", line: "Ribbit, ribbit! Green Frog! Frogs sit on round green lily pads and hop super high!" },
      { id: "duck", emoji: "🦆", label: "Mallard Duck", x: 53, y: 55, sfx: "splash", line: "Quack, quack! Mallard Duck! Ducks paddle webbed feet under the pond water looking for snacks!" },
      { id: "muskrat", emoji: "🦦", label: "Pond Swimmer", x: 78, y: 66, sfx: "splash", line: "Splish, splash! Look swimming by the cattails! Pond swimmers love nibbling water plants along the shore!" },
      { id: "pond-turtle", emoji: "🐢", label: "Painted Turtle", x: 38, y: 36, sfx: "chime", line: "Peekaboo, Painted Turtle! Pond turtles warm their smooth shells on sunny wooden logs!" }
    ]
  },
  barn: {
    name: "🏡 Cozy Red Barn",
    episodeId: "Bg_6uIAVhV8",
    intro: "Cock-a-doodle-doo! Welcome to the sunny red barn! Tap a friendly farm animal!",
    items: [
      { id: "horse", emoji: "🐴", label: "Brown Horse", x: 24, y: 60, sfx: "chime", line: "Neigh! Look at the strong Brown Horse! Horses gallop across green pastures and love crunchy apples!" },
      { id: "hen", emoji: "🐔", label: "Clucking Hen", x: 50, y: 36, sfx: "pop", line: "Bawk, bawk! Happy Barn Hen! Hens peck tasty seeds in the hay and lay warm eggs in cozy nests!" },
      { id: "goat", emoji: "🐐", label: "Playful Goat", x: 77, y: 64, sfx: "chime", line: "Maa, maa! Playful Farm Goat! Goats love climbing hay bales and munching clover!" },
      { id: "cow", emoji: "🐮", label: "Spotted Cow", x: 52, y: 74, sfx: "horn", line: "Moooo! Friendly Spotted Cow! Cows chew soft green grass in the sunny meadow all afternoon!" }
    ]
  },
  polar: {
    name: "❄️ Polar Ice",
    episodeId: "T9vdmRaVw4o",
    intro: "Brrr! Sparkly snow and floating icebergs! Tap an Arctic or Antarctic friend!",
    items: [
      { id: "penguin", emoji: "🐧", label: "Penguin", x: 25, y: 66, sfx: "pop", line: "Waddle, waddle! It's a Penguin! Penguins can't fly in the sky, so they zoom like rockets underwater!" },
      { id: "polar-bear", emoji: "🐻‍❄️", label: "Polar Bear", x: 55, y: 54, sfx: "chime", line: "Whoa, a big snowy Polar Bear! Thick white fur and wide paws help polar bears walk on slippery ice!" },
      { id: "seal", emoji: "🦭", label: "Snowy Seal", x: 80, y: 68, sfx: "splash", line: "Arf, arf! Happy Ice Seal! Seals clap their flippers and dive deep under the chilly waves!" },
      { id: "arctic-whale", emoji: "🐋", label: "Icy Whale", x: 38, y: 30, sfx: "splash", line: "Whoooosh! Giant Whale! Whales sing gentle songs underwater and spout misty water fountains!" }
    ]
  },
  ocean: {
    name: "🌊 Deep Blue Ocean",
    episodeId: "A44kkwUljMM",
    intro: "Bubble, bubble! Let's explore the colorful coral reef under the sea!",
    items: [
      { id: "dolphin", emoji: "🐬", label: "Dolphin", x: 26, y: 38, sfx: "splash", line: "Click, whistle, splash! Playful Dolphin! Dolphins leap through ocean waves and swim in friendly pods!" },
      { id: "octopus", emoji: "🐙", label: "Octopus", x: 54, y: 68, sfx: "pop", line: "Wiggle, wiggle! Clever Octopus! An octopus has eight wiggly arms and hides inside rocky coral caves!" },
      { id: "sea-turtle", emoji: "🐢", label: "Sea Turtle", x: 78, y: 44, sfx: "splash", line: "Glide, glide! Gentle Sea Turtle! Sea turtles use big flippers like wings to cruise across the ocean!" },
      { id: "crab", emoji: "🦀", label: "Red Crab", x: 28, y: 76, sfx: "pop", line: "Snip, snap! Little Red Crab! Crabs walk sideways across the sandy ocean floor!" }
    ]
  },
  safari: {
    name: "🦁 Sunny Safari",
    episodeId: "XhWwEkmjUak",
    intro: "Welcome to the golden grassland savanna! Who is visiting the watering hole?",
    items: [
      { id: "lion", emoji: "🦁", label: "Golden Lion", x: 24, y: 66, sfx: "horn", line: "Roaaar! Golden Lion! Male lions have big fluffy manes and love napping in warm shady grass!" },
      { id: "giraffe", emoji: "🦒", label: "Tall Giraffe", x: 52, y: 40, sfx: "chime", line: "Stretch up high! Tall Giraffe! Giraffes use their super long necks to munch treetop acacia leaves!" },
      { id: "elephant", emoji: "🐘", label: "Elephant", x: 79, y: 60, sfx: "horn", line: "Pa-woo! Gentle Giant Elephant! Elephants scoop cool water in their trunks for a refreshing shower!" },
      { id: "hippo", emoji: "🦛", label: "Splashing Hippo", x: 54, y: 78, sfx: "splash", line: "Big splash! Happy Hippo! Hippos stay cool submerged in muddy rivers with their ears peeking out!" }
    ]
  },
  desert: {
    name: "🌵 Golden Desert",
    episodeId: "XhWwEkmjUak",
    intro: "Warm golden sand dunes and tall green cacti! Tap to meet desert explorers!",
    items: [
      { id: "camel", emoji: "🐪", label: "Desert Camel", x: 26, y: 58, sfx: "chime", line: "Step, step! Desert Camel! Camels have wide soft feet made for walking smoothly across sandy dunes!" },
      { id: "lizard", emoji: "🦎", label: "Sunny Lizard", x: 54, y: 72, sfx: "pop", line: "Zip, zip! Quick Desert Lizard! Lizards warm up on sunny canyon rocks and rest in cool shade at noon!" },
      { id: "scorpion-owl", emoji: "🦉", label: "Cactus Owl", x: 76, y: 36, sfx: "hoot", line: "Peekaboo! Tiny Cactus Owl! Elf owls tuck their nests right inside tall green desert cactus plants!" },
      { id: "tortoise", emoji: "🐢", label: "Desert Tortoise", x: 78, y: 74, sfx: "chime", line: "Slow and steady! Desert Tortoise! Tortoises dig cool underground burrows to beat the desert sun!" }
    ]
  }
};

const VEHICLES = [
  { id: "tractor", emoji: "🚜", label: "Red Tractor", x: 20, y: 40, line: "Scrub, scrub, sparkle! Big Red Tractor! Giant bumpy tires pull plows and hay wagons across muddy fields!" },
  { id: "dump-truck", emoji: "🚚", label: "Dump Truck", x: 42, y: 38, line: "Whoosh, all clean! Heavy Dump Truck! Dump trucks haul sand and gravel and tip their back beds high!" },
  { id: "fire-truck", emoji: "🚒", label: "Fire Engine", x: 64, y: 40, line: "Shiny bright red! Helper Fire Engine! Fire engines carry tall ladders and big water hoses to help!" },
  { id: "school-bus", emoji: "🚌", label: "School Bus", x: 84, y: 40, line: "Beep, beep, sparkling yellow! Sunny School Bus! Buses carry friends safely to school and back home!" },
  { id: "excavator", emoji: "🏗️", label: "Digger Crane", x: 28, y: 74, line: "Bubble wash complete! Big Construction Crane! Cranes lift heavy steel beams high into the sky!" },
  { id: "recycle-truck", emoji: "🚛", label: "Helper Hauler", x: 54, y: 74, line: "Squeaky clean! Big Green Hauler! Haulers carry supplies and recyclables to keep neighborhoods tidy!" },
  { id: "ambulance", emoji: "🚑", label: "Rescue Van", x: 78, y: 74, line: "Sparkle shine! Helper Rescue Van! Community helpers ride inside to lend a caring hand!" }
];

const DINO_EGGS = [
  { id: "trex", eggIcon: "🔴", clueIcon: "🦎", dinoIcon: "🦖", eggLabel: "Red Spotted Egg", clueLabel: "Green Tail!", dinoLabel: "Green T-Rex", x: 20, y: 40,
    clueLine: "Crack, crack! Look peeking out of the red spotted egg—a bouncy green tail! Tap again to hatch!",
    hatchLine: "Pop! Look who hatched—a friendly Green T-Rex! T-Rex walked on two strong back legs with tiny front arms!" },
  { id: "triceratops", eggIcon: "🔵", clueIcon: "👑", dinoIcon: "🦕", eggLabel: "Blue Spotted Egg", clueLabel: "Three Horns!", dinoLabel: "Blue Triceratops", x: 50, y: 38,
    clueLine: "Knock, knock! Three smooth horns are peeking out of the blue egg! Tap again to hatch!",
    hatchLine: "Pop! It's a gentle Blue Triceratops! Triceratops had three horns and a big frill, and munched green plants!" },
  { id: "brachiosaurus", eggIcon: "🟢", clueIcon: "🌿", dinoIcon: "🦕", eggLabel: "Tall Green Egg", clueLabel: "Long Neck!", dinoLabel: "Tall Long-Neck", x: 80, y: 40,
    clueLine: "Crunch, crunch! A super long orange neck with a leaf popped out of the tall green egg! Tap again!",
    hatchLine: "Pop! Amazing! A giant Brachiosaurus! Its super tall neck reached high treetop leaves like a giraffe!" },
  { id: "stegosaurus", eggIcon: "🟣", clueIcon: "⭐", dinoIcon: "🦕", eggLabel: "Purple Star Egg", clueLabel: "Yellow Plates!", dinoLabel: "Spiky-Back Dino", x: 22, y: 76,
    clueLine: "Thump, thump! Bright yellow plates just popped out of the purple star egg! Tap again to hatch!",
    hatchLine: "Pop! Yay! A happy Purple Stegosaurus with sunny yellow plates along its arched back!" },
  { id: "pterodactyl", eggIcon: "🟡", clueIcon: "🪽", dinoIcon: "🦖", eggLabel: "Sunny Yellow Egg", clueLabel: "Flappy Wings!", dinoLabel: "Flying Dino", x: 52, y: 76,
    clueLine: "Flap, flap! Two wide yellow wings are wiggling out of the yellow egg! Tap again to hatch!",
    hatchLine: "Pop! Whoosh! A flying Yellow Pterodactyl gliding smoothly through prehistoric skies!" },
  { id: "ankylosaurus", eggIcon: "🟠", clueIcon: "🛡️", dinoIcon: "🦕", eggLabel: "Orange Dot Egg", clueLabel: "Bumpy Tail!", dinoLabel: "Armored Dino", x: 80, y: 76,
    clueLine: "Bonk, bonk! A round bumpy drum tail is tapping out of the orange egg! Tap again to hatch!",
    hatchLine: "Pop! Hooray! A strong Orange Ankylosaurus wearing a bumpy shell like a giant friendly turtle!" }
];

const ABC_DATA = [
  ["A","🍎","Apple","crunchy red fruit that grows on orchard trees"],
  ["B","🚌","Bus","big yellow wheels rolling down the street"],
  ["C","🐮","Cow","friendly farm friend that says moooo"],
  ["D","🐬","Dolphin","playful ocean swimmer leaping in the waves"],
  ["E","🐘","Elephant","gentle giant with a long helpful trunk"],
  ["F","🐸","Frog","bouncy green hopper on a pond lily pad"],
  ["G","🦒","Giraffe","tallest animal munching treetop leaves"],
  ["H","🐴","Horse","fast galloper inside the cozy red barn"],
  ["I","🧊","Iceberg","sparkly floating ice in the polar sea"],
  ["J","🚙","Jeep","bouncy adventure car driving up bumpy hills"],
  ["K","🦘","Kangaroo","champion jumper with a cozy front pouch"],
  ["L","🦁","Lion","golden savanna cat with a fluffy mane"],
  ["M","🐒","Monkey","clever tree climber swinging on jungle vines"],
  ["N","🪺","Nest","woven twig home holding colorful eggs"],
  ["O","🦉","Owl","nighttime bird saying hoo-hoo in the pines"],
  ["P","🐧","Penguin","tuxedo swimmer zooming through icy water"],
  ["Q","🦆","Quack","happy sound a mallard duck makes on the pond"],
  ["R","🤖","Robot","that's Bip! Your sky-blue learning buddy"],
  ["S","⭐","Star","twinkling light shining in the cozy night sky"],
  ["T","🚜","Tractor","hardworking farm machine with giant tires"],
  ["U","☂️","Umbrella","colorful canopy keeping raindrops away"],
  ["V","🌋","Volcano","rumbling mountain from dinosaur island"],
  ["W","🐳","Whale","singing ocean giant spouting misty water"],
  ["X","xylophone","🎶","Xylophone","wooden rainbow keys making happy music"],
  ["Y","🛥️","Yacht","breezy sailboat gliding across blue water"],
  ["Z","🦓","Zebra","striped savanna runner galloping with friends"]
];

/* ==========================================================================
   ZERO-LAG AUDIO ENGINE (Preloaded Studio MP3s + 0ms Kid-Friendly Neural/Local)
   ========================================================================== */
let audioCtx = null;
let voiceMode = "peppy"; // "peppy" | "calm" | "sfx"
let cachedVoices = [];
let preferredVoice = null;
let availableMp3Set = new Set();
let preloadedAudioMap = new Map();
let activeAudioEl = null;
let speechTimer = null;

function ensureAudioCtx() {
  if (!audioCtx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (AC) audioCtx = new AC();
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
}

// Instant hardware-synthesized toy sound effects (0ms latency, zero network wait)
function playToySfx(type = "chime") {
  try {
    ensureAudioCtx();
    if (!audioCtx) return;
    const now = audioCtx.currentTime;

    const note = (freq, start, dur, wave = "sine", vol = 0.16) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = wave;
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.001, start);
      gain.gain.exponentialRampToValueAtTime(vol, start + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(start);
      osc.stop(start + dur + 0.02);
    };

    if (type === "pop" || type === "hatch") {
      note(523.25, now, 0.11, "triangle", 0.18);
      note(659.25, now + 0.07, 0.12, "triangle", 0.18);
      note(783.99, now + 0.14, 0.16, "sine", 0.20);
      if (type === "hatch") note(1046.5, now + 0.22, 0.28, "sine", 0.22);
    } else if (type === "wash" || type === "splash") {
      note(392.0, now, 0.10, "sine", 0.15);
      note(587.33, now + 0.08, 0.12, "sine", 0.16);
      note(880.0, now + 0.16, 0.22, "triangle", 0.18);
    } else if (type === "hoot") {
      note(440.0, now, 0.18, "sine", 0.16);
      note(392.0, now + 0.22, 0.26, "sine", 0.15);
    } else if (type === "horn") {
      note(349.23, now, 0.13, "triangle", 0.16);
      note(440.0, now + 0.14, 0.20, "triangle", 0.17);
    } else {
      note(587.33, now, 0.13, "sine", 0.16);
      note(880.0, now + 0.09, 0.20, "sine", 0.16);
    }
  } catch (_) {}
}

// Rank browser voices to pick the brightest, warmest child/youthful voice & block robotic adult voices
function selectKidFriendlyVoice() {
  if (!("speechSynthesis" in window)) return;
  cachedVoices = window.speechSynthesis.getVoices() || [];
  if (!cachedVoices.length) return;

  const enVoices = cachedVoices.filter(v => /^en(-|_)/i.test(v.lang));
  const pool = enVoices.length ? enVoices : cachedVoices;

  const blocked = /(david|mark|alex|daniel|fred|ralph|albert|bruce|grandpa|reed|rocko|espeak|zarvox|trinoids|whisper)/i;
  const topKidAndBright = [
    /ana.*natural/i,          // Microsoft Ana Online (Natural) — real child neural voice!
    /maisie.*natural/i,       // Child neural voice (en-GB)
    /aria.*natural/i,
    /jenny.*natural/i,
    /ava.*(premium|enhanced|natural)/i,
    /samantha/i,
    /google us english/i,
    /allison/i,
    /zoe/i,
    /tessa/i,
    /karen/i,
    /victoria/i,
    /moira/i
  ];

  const cleanPool = pool.filter(v => !blocked.test(v.name));
  const searchList = cleanPool.length ? cleanPool : pool;

  for (const pattern of topKidAndBright) {
    const hit = searchList.find(v => pattern.test(v.name));
    if (hit) {
      preferredVoice = hit;
      return;
    }
  }
  preferredVoice = searchList[0] || null;
}

if ("speechSynthesis" in window) {
  selectKidFriendlyVoice();
  window.speechSynthesis.onvoiceschanged = selectKidFriendlyVoice;
}

// Check audio/manifest.json once on startup so we NEVER incur 404 lag on clicks
fetch("audio/manifest.json")
  .then(r => (r.ok ? r.json() : { files: [] }))
  .then(data => {
    if (data && Array.isArray(data.files)) {
      data.files.forEach(fn => {
        availableMp3Set.add(fn);
        const a = new Audio(`audio/${fn}`);
        a.preload = "auto";
        preloadedAudioMap.set(fn, a);
      });
    }
  })
  .catch(() => {});

function setBipTalkingState(isTalking) {
  const bipBtn = document.getElementById("bipBuddyBtn");
  if (!bipBtn) return;
  bipBtn.classList.toggle("talking", isTalking);
}

function speakWithBip(clipId, text, sfxType = "chime") {
  // 1. Update speech bubble immediately (0ms)
  const bubble = document.getElementById("bipSpeechBubble");
  if (bubble) bubble.textContent = text;

  // 2. Play instant hardware toy sound effect (0ms)
  playToySfx(sfxType);

  // Stop any prior speech immediately so rapid taps never queue or lag
  if (activeAudioEl) {
    activeAudioEl.pause();
    activeAudioEl.currentTime = 0;
    activeAudioEl = null;
  }
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
  if (speechTimer) clearTimeout(speechTimer);

  if (voiceMode === "sfx") {
    setBipTalkingState(true);
    speechTimer = setTimeout(() => setBipTalkingState(false), 650);
    return;
  }

  // 3. Layer 1: Preloaded Studio Gigi MP3 (if present in /audio/manifest.json -> 0ms!)
  const mp3File = `${clipId}.mp3`;
  if (availableMp3Set.has(mp3File)) {
    const audio = preloadedAudioMap.get(mp3File) || new Audio(`audio/${mp3File}`);
    activeAudioEl = audio;
    audio.currentTime = 0;
    setBipTalkingState(true);
    audio.onended = () => setBipTalkingState(false);
    audio.play().catch(() => setBipTalkingState(false));
    return;
  }

  // 4. Layer 2: Instant 0ms Local Friendly Kid-Buddy Voice (Zero Network Lag)
  if ("speechSynthesis" in window) {
    if (!preferredVoice) selectKidFriendlyVoice();
    const utter = new SpeechSynthesisUtterance(text);
    if (preferredVoice) utter.voice = preferredVoice;
    const isNaturalChild = preferredVoice && /(ana|maisie)/i.test(preferredVoice.name);
    if (voiceMode === "peppy") {
      utter.pitch = isNaturalChild ? 1.06 : 1.34;
      utter.rate = isNaturalChild ? 1.0 : 0.99;
    } else {
      utter.pitch = isNaturalChild ? 1.0 : 1.18;
      utter.rate = 0.92;
    }
    setBipTalkingState(true);
    utter.onend = () => setBipTalkingState(false);
    utter.onerror = () => setBipTalkingState(false);
    window.speechSynthesis.speak(utter);
    speechTimer = setTimeout(() => setBipTalkingState(false), 6500);
  }
}

/* ==========================================================================
   ILLUSTRATED SVG ENVIRONMENT BACKDROPS
   ========================================================================== */
function getEnvironmentSVG(sceneKey) {
  const scenes = {
    forest: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <defs>
        <linearGradient id="skyF" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#BCE7FD"/><stop offset="100%" stop-color="#E9F8E5"/></linearGradient>
      </defs>
      <rect width="1000" height="500" fill="url(#skyF)"/>
      <circle cx="860" cy="88" r="52" fill="#FFE07D" opacity="0.9"/>
      <path d="M0 320 Q260 250 540 310 T1000 290 L1000 500 L0 500 Z" fill="#8ECF82"/>
      <path d="M0 375 Q320 330 680 380 T1000 360 L1000 500 L0 500 Z" fill="#63B462"/>
      <path d="M390 385 Q520 420 640 500 L470 500 Q420 435 350 390 Z" fill="#6BC5E8"/>
      <g fill="#3E8E53">
        <polygon points="110,120 45,335 175,335"/><polygon points="110,75 60,245 160,245"/>
        <polygon points="890,110 820,345 960,345"/><polygon points="890,65 838,240 942,240"/>
        <polygon points="735,135 680,320 790,320"/>
      </g>
      <rect x="100" y="335" width="20" height="42" fill="#7D5233"/>
      <rect x="880" y="345" width="22" height="42" fill="#7D5233"/>
      <rect x="210" y="398" width="130" height="28" rx="14" fill="#8B5A36"/>
    </svg>`,
    pond: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <rect width="1000" height="500" fill="#C9EEFF"/>
      <circle cx="150" cy="84" r="46" fill="#FFE27A"/>
      <path d="M0 255 Q280 215 560 250 T1000 240 L1000 500 L0 500 Z" fill="#8ED081"/>
      <ellipse cx="520" cy="365" rx="430" ry="125" fill="#4FB6E6"/>
      <ellipse cx="520" cy="365" rx="375" ry="98" fill="#6EC9F2"/>
      <ellipse cx="265" cy="375" rx="68" ry="26" fill="#5BBF62"/>
      <ellipse cx="730" cy="392" rx="62" ry="24" fill="#5BBF62"/>
      <rect x="855" y="210" width="6" height="140" fill="#4E944F"/><rect x="851" y="220" width="14" height="42" rx="7" fill="#7A4928"/>
      <rect x="880" y="230" width="6" height="130" fill="#4E944F"/><rect x="876" y="242" width="14" height="38" rx="7" fill="#7A4928"/>
    </svg>`,
    barn: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <rect width="1000" height="500" fill="#CBEBFF"/>
      <circle cx="850" cy="82" r="48" fill="#FFE074"/>
      <path d="M0 285 Q350 240 690 280 T1000 265 L1000 500 L0 500 Z" fill="#8AD16B"/>
      <polygon points="500,95 365,195 635,195" fill="#B6322B"/>
      <rect x="385" y="195" width="230" height="150" fill="#D9443B"/>
      <rect x="455" y="235" width="90" height="110" fill="#FFFFFF" opacity="0.92"/>
      <rect x="463" y="243" width="74" height="94" fill="#B6322B"/>
      <g fill="#FFFFFF" opacity="0.9">
        <rect x="80" y="305" width="260" height="10" rx="5"/><rect x="80" y="330" width="260" height="10" rx="5"/>
        <rect x="660" y="305" width="260" height="10" rx="5"/><rect x="660" y="330" width="260" height="10" rx="5"/>
      </g>
      <ellipse cx="770" cy="375" rx="54" ry="34" fill="#F2C14E"/>
    </svg>`,
    polar: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <defs><linearGradient id="polarSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#9BD6FF"/><stop offset="100%" stop-color="#E9F7FF"/></linearGradient></defs>
      <rect width="1000" height="500" fill="url(#polarSky)"/>
      <polygon points="140,120 35,310 255,310" fill="#FFFFFF"/>
      <polygon points="820,105 690,310 940,310" fill="#F2FAFF"/>
      <rect x="0" y="305" width="1000" height="195" fill="#3B9AD9"/>
      <ellipse cx="265" cy="365" rx="145" ry="42" fill="#FFFFFF"/>
      <ellipse cx="565" cy="335" rx="155" ry="46" fill="#F5FBFF"/>
      <ellipse cx="805" cy="385" rx="130" ry="38" fill="#FFFFFF"/>
    </svg>`,
    ocean: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <defs><linearGradient id="seaG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#4CC3F7"/><stop offset="100%" stop-color="#176BA0"/></linearGradient></defs>
      <rect width="1000" height="500" fill="url(#seaG)"/>
      <path d="M0 410 Q280 375 560 410 T1000 395 L1000 500 L0 500 Z" fill="#F6D799"/>
      <path d="M110 430 Q95 340 130 325 Q150 365 165 430 Z" fill="#FF7F8A"/>
      <path d="M845 425 Q825 320 865 305 Q895 350 900 425 Z" fill="#FFA952"/>
      <circle cx="220" cy="180" r="12" fill="#FFF" opacity="0.35"/><circle cx="245" cy="130" r="8" fill="#FFF" opacity="0.35"/>
      <circle cx="740" cy="200" r="14" fill="#FFF" opacity="0.35"/><circle cx="765" cy="145" r="9" fill="#FFF" opacity="0.35"/>
    </svg>`,
    safari: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <defs><linearGradient id="safG" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#FFE19C"/><stop offset="100%" stop-color="#FFF5D6"/></linearGradient></defs>
      <rect width="1000" height="500" fill="url(#safG)"/>
      <circle cx="840" cy="95" r="56" fill="#FFC552"/>
      <path d="M0 300 Q340 265 680 300 T1000 285 L1000 500 L0 500 Z" fill="#E8C266"/>
      <ellipse cx="555" cy="405" rx="225" ry="52" fill="#5CBCE8"/>
      <rect x="135" y="185" width="18" height="125" fill="#7D4E2D"/>
      <ellipse cx="145" cy="175" rx="95" ry="28" fill="#68A347"/>
    </svg>`,
    desert: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <rect width="1000" height="500" fill="#FFE9B5"/>
      <circle cx="170" cy="92" r="52" fill="#FFBE47"/>
      <path d="M0 295 Q250 225 530 290 T1000 265 L1000 500 L0 500 Z" fill="#F2C06B"/>
      <path d="M0 365 Q360 315 710 370 T1000 350 L1000 500 L0 500 Z" fill="#E5AA50"/>
      <rect x="755" y="175" width="24" height="145" rx="12" fill="#549F52"/>
      <rect x="725" y="215" width="32" height="16" rx="8" fill="#549F52"/><rect x="725" y="190" width="16" height="36" rx="8" fill="#549F52"/>
      <rect x="777" y="205" width="32" height="16" rx="8" fill="#549F52"/><rect x="793" y="178" width="16" height="40" rx="8" fill="#549F52"/>
    </svg>`,
    vehicles: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <rect width="1000" height="500" fill="#D6F1FF"/>
      <rect x="85" y="55" width="830" height="340" rx="34" fill="#A9E0FA" stroke="#FFFFFF" stroke-width="8"/>
      <rect x="115" y="85" width="54" height="290" rx="26" fill="#4BA9E6"/>
      <rect x="831" y="85" width="54" height="290" rx="26" fill="#F26659"/>
      <rect x="0" y="380" width="1000" height="120" fill="#CBD5E1"/>
      <circle cx="230" cy="130" r="22" fill="#FFF" opacity="0.72"/><circle cx="760" cy="145" r="26" fill="#FFF" opacity="0.72"/>
      <circle cx="500" cy="110" r="18" fill="#FFF" opacity="0.72"/><circle cx="640" cy="210" r="16" fill="#FFF" opacity="0.65"/>
    </svg>`,
    dinos: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <rect width="1000" height="350" fill="#FBF2DE"/>
      <rect x="620" y="0" width="380" height="350" fill="#C9E8F8"/>
      <rect x="55" y="45" width="165" height="210" rx="16" fill="#FFFDF7" stroke="#E5D5B5" stroke-width="10"/>
      <rect x="0" y="340" width="1000" height="160" fill="#D89D5B"/>
      <ellipse cx="500" cy="385" rx="370" ry="62" fill="#C9964C"/>
      <ellipse cx="500" cy="380" rx="340" ry="48" fill="#DFB067"/>
    </svg>`,
    abcs: `<svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid slice" width="100%" height="100%">
      <rect width="1000" height="330" fill="#FDF3DF"/>
      <rect x="0" y="325" width="1000" height="175" fill="#E2AD6B"/>
      <circle cx="900" cy="80" r="46" fill="#FFE082" opacity="0.7"/>
    </svg>`
  };
  return scenes[sceneKey] || scenes.forest;
}

/* ==========================================================================
   GAME STATE & RENDERING
   ========================================================================== */
let currentWorld = "animals"; // animals | vehicles | dinos | abcs
let currentHabitat = "forest";
const discoveredSet = new Set();
const washedVehicles = new Set();
const dinoEggStage = {}; // id -> 0 (egg), 1 (clue), 2 (hatched)

function updateStarsCounter(totalInScene, currentIds) {
  const found = currentIds.filter(id => discoveredSet.has(id)).length;
  const pill = document.getElementById("sceneStarsPill");
  if (pill) pill.textContent = `Scene Stars: ${found} / ${totalInScene} ⭐`;
}

function setMatchingEpisodeButton(epId, labelText) {
  const btn = document.getElementById("watchMatchingBtn");
  if (!btn) return;
  btn.onclick = () => loadEpisodeInTheater(epId, true);
  btn.innerHTML = `▶️ Watch ${labelText}`;
}

function renderGameStage() {
  const backdropEl = document.getElementById("dioramaBackdrop");
  const badgeEl = document.getElementById("sceneTitleBadge");
  const subBar = document.getElementById("subworldBar");
  const playfield = document.getElementById("dioramaPlayfield");

  document.querySelectorAll(".world-tab").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.world === currentWorld);
  });

  if (currentWorld === "animals") {
    subBar.style.display = "flex";
    subBar.innerHTML = Object.entries(HABITATS).map(([key, h]) => `
      <button class="subworld-chip ${key === currentHabitat ? "active" : ""}" data-hab="${key}">${h.name}</button>
    `).join("");
    subBar.querySelectorAll(".subworld-chip").forEach(b => {
      b.onclick = () => {
        currentHabitat = b.dataset.hab;
        renderGameStage();
        speakWithBip(`hab-${currentHabitat}`, HABITATS[currentHabitat].intro, "chime");
      };
    });

    const hab = HABITATS[currentHabitat];
    backdropEl.innerHTML = getEnvironmentSVG(currentHabitat);
    badgeEl.textContent = hab.name;
    setMatchingEpisodeButton(hab.episodeId, "Habitat Episode");
    updateStarsCounter(hab.items.length, hab.items.map(i => i.id));

    playfield.innerHTML = `<div class="hotspot-stage">${hab.items.map(item => `
      <button class="env-actor ${discoveredSet.has(item.id) ? "discovered" : ""}"
              style="left:${item.x}%; top:${item.y}%;" data-id="${item.id}">
        <span class="actor-star">⭐</span>
        <span class="actor-emoji">${item.emoji}</span>
        <span class="actor-label">${item.label}</span>
      </button>
    `).join("")}</div>`;

    playfield.querySelectorAll(".env-actor").forEach(el => {
      el.onclick = () => {
        const item = hab.items.find(i => i.id === el.dataset.id);
        discoveredSet.add(item.id);
        el.classList.remove("speaking-pop");
        void el.offsetWidth;
        el.classList.add("discovered", "speaking-pop");
        updateStarsCounter(hab.items.length, hab.items.map(i => i.id));
        speakWithBip(item.id, item.line, item.sfx);
      };
    });
  } else if (currentWorld === "vehicles") {
    subBar.style.display = "flex";
    subBar.innerHTML = `<button class="subworld-chip active" id="resetMudBtn">🔄 Splash Mud Again!</button>`;
    document.getElementById("resetMudBtn").onclick = () => {
      washedVehicles.clear();
      renderGameStage();
      speakWithBip("mud-reset", "Splat! All the trucks are muddy again! Tap each vehicle to scrub it sparkling clean!", "splash");
    };

    backdropEl.innerHTML = getEnvironmentSVG("vehicles");
    badgeEl.textContent = "🧼 Bip's Magic Car Wash Bay";
    setMatchingEpisodeButton("g6gomczRjYw", "Car Wash Episode");
    updateStarsCounter(VEHICLES.length, VEHICLES.map(v => v.id));

    playfield.innerHTML = `<div class="hotspot-stage">${VEHICLES.map(v => {
      const clean = washedVehicles.has(v.id);
      return `<button class="env-actor ${clean ? "is-clean discovered" : "is-muddy"}"
                      style="left:${v.x}%; top:${v.y}%;" data-id="${v.id}">
        <span class="actor-star">⭐</span>
        <span class="actor-emoji">${v.emoji}</span>
        <span class="actor-label">${v.label}</span>
      </button>`;
    }).join("")}</div>`;

    playfield.querySelectorAll(".env-actor").forEach(el => {
      el.onclick = () => {
        const v = VEHICLES.find(x => x.id === el.dataset.id);
        washedVehicles.add(v.id);
        discoveredSet.add(v.id);
        el.classList.remove("is-muddy", "speaking-pop");
        void el.offsetWidth;
        el.classList.add("is-clean", "discovered", "speaking-pop");
        updateStarsCounter(VEHICLES.length, VEHICLES.map(i => i.id));
        speakWithBip(v.id, v.line, "wash");
      };
    });
  } else if (currentWorld === "dinos") {
    subBar.style.display = "flex";
    subBar.innerHTML = `<button class="subworld-chip active" id="resetEggsBtn">🥚 Close All Mystery Eggs!</button>`;
    document.getElementById("resetEggsBtn").onclick = () => {
      Object.keys(dinoEggStage).forEach(k => delete dinoEggStage[k]);
      renderGameStage();
      speakWithBip("eggs-reset", "All six dinosaur mystery eggs are tucked back in the straw nest! Tap an egg to crack it!", "pop");
    };

    backdropEl.innerHTML = getEnvironmentSVG("dinos");
    badgeEl.textContent = "🥚 Sunlit Dinosaur Mystery Nest";
    setMatchingEpisodeButton("LCwZiT2EIik", "Dino Eggs Episode");
    updateStarsCounter(DINO_EGGS.length, DINO_EGGS.map(d => d.id));

    playfield.innerHTML = `<div class="hotspot-stage">${DINO_EGGS.map(d => {
      const st = dinoEggStage[d.id] || 0;
      const icon = st === 0 ? d.eggIcon : (st === 1 ? d.clueIcon : d.dinoIcon);
      const lbl = st === 0 ? d.eggLabel : (st === 1 ? d.clueLabel : d.dinoLabel);
      const tag = st === 0 ? "Tap to Crack!" : (st === 1 ? "Peek! Tap to Hatch" : "Hatched! 🎉");
      return `<button class="env-actor ${st === 2 ? "discovered" : ""}"
                      style="left:${d.x}%; top:${d.y}%;" data-id="${d.id}">
        <span class="actor-star">⭐</span>
        <span class="actor-emoji">${icon}</span>
        <span class="actor-label">${lbl}</span>
        <span class="actor-state-tag">${tag}</span>
      </button>`;
    }).join("")}</div>`;

    playfield.querySelectorAll(".env-actor").forEach(el => {
      el.onclick = () => {
        const d = DINO_EGGS.find(x => x.id === el.dataset.id);
        const cur = dinoEggStage[d.id] || 0;
        if (cur === 0) {
          dinoEggStage[d.id] = 1;
          speakWithBip(`${d.id}-clue`, d.clueLine, "pop");
        } else {
          dinoEggStage[d.id] = 2;
          discoveredSet.add(d.id);
          speakWithBip(d.id, d.hatchLine, "hatch");
        }
        renderGameStage();
      };
    });
  } else if (currentWorld === "abcs") {
    subBar.style.display = "none";
    backdropEl.innerHTML = getEnvironmentSVG("abcs");
    badgeEl.textContent = "🔤 Sunlit Playroom Wooden ABC Blocks";
    setMatchingEpisodeButton("sDwtEwIJ6zs", "12-Min A–Z Episode");
    updateStarsCounter(26, ABC_DATA.map(a => `abc-${a[0]}`));

    playfield.innerHTML = `<div class="abc-playroom-grid">${ABC_DATA.map(a => {
      const letter = a[0];
      const icon = a.length === 5 ? a[2] : a[1];
      const word = a.length === 5 ? a[3] : a[2];
      const fact = a.length === 5 ? a[4] : a[3];
      return `<button class="abc-block" data-letter="${letter}" data-word="${word}" data-fact="${fact}">
        <span class="abc-letters">${letter}${letter.toLowerCase()}</span>
        <span class="abc-icon">${icon}</span>
        <span class="abc-word">${word}</span>
      </button>`;
    }).join("")}</div>`;

    playfield.querySelectorAll(".abc-block").forEach(btn => {
      btn.onclick = () => {
        const l = btn.dataset.letter;
        const w = btn.dataset.word;
        const f = btn.dataset.fact;
        discoveredSet.add(`abc-${l}`);
        updateStarsCounter(26, ABC_DATA.map(a => `abc-${a[0]}`));
        speakWithBip(`letter-${l.toLowerCase()}`, `${l}! ${l} is for ${w}—a ${f}!`, "chime");
      };
    });
  }
}

/* ==========================================================================
   YOUTUBE EPISODE THEATER & PAGE INTERACTIONS
   ========================================================================== */
function loadEpisodeInTheater(videoId, scrollIntoView = false) {
  const iframe = document.getElementById("ytMainIframe");
  const titleEl = document.getElementById("ytNowPlayingTitle");
  const ep = EPISODES.find(e => e.id === videoId) || EPISODES[0];

  if (iframe) {
    iframe.src = `https://www.youtube-nocookie.com/embed/${ep.id}?rel=0&modestbranding=1`;
  }
  if (titleEl) titleEl.textContent = ep.title;

  document.querySelectorAll(".episode-row-btn").forEach(b => {
    b.classList.toggle("active", b.dataset.vid === ep.id);
  });

  if (scrollIntoView) {
    document.getElementById("watch")?.scrollIntoView({ behavior: "smooth" });
  }
}

function initPage() {
  // World tab switching
  document.querySelectorAll(".world-tab").forEach(tab => {
    tab.onclick = () => {
      currentWorld = tab.dataset.world;
      renderGameStage();
      const greetings = {
        animals: HABITATS[currentHabitat].intro,
        vehicles: "Welcome to Bip's Magic Car Wash! Tap any muddy vehicle to scrub it sparkling clean!",
        dinos: "Look at all six dinosaur mystery eggs in the straw nest! Tap an egg to see what's peeking inside!",
        abcs: "Let's explore wooden letter blocks on the playroom floor! Tap any letter from A to Z!"
      };
      speakWithBip(`world-${currentWorld}`, greetings[currentWorld], "chime");
    };
  });

  // Bip SVG Buddy greeting
  const bipBtn = document.getElementById("bipBuddyBtn");
  if (bipBtn) {
    bipBtn.onclick = () => {
      speakWithBip("bip-hello", "Hi friend! I'm Bip the Bot! Tap anything inside the scene to play and discover together!", "hatch");
    };
  }

  // Voice mode selector
  const voiceSelect = document.getElementById("voiceModeSelect");
  if (voiceSelect) {
    voiceSelect.onchange = e => {
      voiceMode = e.target.value;
      speakWithBip("voice-check", "Yay! Let's play and explore together!", "pop");
    };
  }

  // Cozy Evening Night Mode toggle
  const nightBtn = document.getElementById("nightModeBtn");
  if (nightBtn) {
    nightBtn.onclick = () => {
      const isNight = document.body.classList.toggle("night-mode");
      nightBtn.textContent = isNight ? "☀️ Sunny Day" : "🌙 Cozy Evening";
    };
  }

  // Populate Episode Playlist Stack
  const stack = document.getElementById("episodePlaylistStack");
  if (stack) {
    stack.innerHTML = EPISODES.map((ep, idx) => `
      <button class="episode-row-btn ${idx === 0 ? "active" : ""}" data-vid="${ep.id}">
        <span class="ep-badge-icon">${ep.icon}</span>
        <div>
          <div class="ep-meta-title">${ep.title}</div>
          <div class="ep-meta-sub">${ep.meta}</div>
        </div>
      </button>
    `).join("");
    stack.querySelectorAll(".episode-row-btn").forEach(b => {
      b.onclick = () => loadEpisodeInTheater(b.dataset.vid, false);
    });
  }

  // Reciprocity Subscribe Toast when downloading free Coloring Book PDF
  const pdfBtn = document.getElementById("downloadColoringBtn");
  const toast = document.getElementById("reciprocityToast");
  const closeToast = document.getElementById("closeToastBtn");
  if (pdfBtn && toast) {
    pdfBtn.addEventListener("click", () => {
      setTimeout(() => toast.classList.add("visible"), 600);
    });
  }
  if (closeToast && toast) {
    closeToast.onclick = () => toast.classList.remove("visible");
  }

  renderGameStage();
}

document.addEventListener("DOMContentLoaded", initPage);
