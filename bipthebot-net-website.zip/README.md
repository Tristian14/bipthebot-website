# Play & Learn with Bip — `bipthebot.net`

Official static website, interactive environment learning game, episode theater, and printable coloring book pack for **Play & Learn with Bip** (`@playlearnwithbip`).

## Folder Structure (Upload All Files Directly to Root of Your GitHub Repo)
- `index.html` — Upscale studio landing page, diorama game, YouTube theater & social hub
- `styles.css` — Honey-marigold & alabaster studio theme + Cozy Evening Night Mode
- `game.js` — 4 environment dioramas + zero-lag (`0ms`) kid-friendly voice & toy sound engine
- `CNAME` — Pre-configured for `bipthebot.net` on GitHub Pages
- `assets/` — Optimized studio Bip images (`bip-hero.jpg`, `bip-avatar.jpg`, `favicon.png`) + 4-page `bip-coloring-book.pdf`
- `audio/manifest.json` & `tools/generate_gigi_voices.py` — Instant preloaded MP3 support for ElevenLabs Gigi voice clips
