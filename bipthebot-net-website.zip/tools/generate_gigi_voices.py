"""
Optional 1-Click Studio Voice Generator for bipthebot.net
Generates ultra-fast static MP3s using your ElevenLabs "Gigi" voice and updates audio/manifest.json!
Usage:
  pip install requests
  export ELEVENLABS_API_KEY="your_key_here"
  python tools/generate_gigi_voices.py
"""
import os, re, json, requests

VOICE_ID = "jBpfuIE2acCO8z3wKNLl"  # ElevenLabs "Gigi - Cute, Peppy, Energetic"
API_KEY = os.environ.get("ELEVENLABS_API_KEY", "").strip()

CLIPS = {
    "bip-hello": "Hi friend! I'm Bip the Bot! Tap anything inside the scene to play and discover together!",
    "fox": "Ooh, a Red Fox! Red foxes have fluffy orange tails to stay warm in cozy forest dens!",
    "owl": "Hoo, hoo! That's a Forest Owl! Owls perch high in pine trees and see in the starry night!",
    "beaver": "Look, a Busy Beaver! Beavers build neat wooden lodges across forest streams and slap their flat tails!",
    "deer": "Hi, gentle Woodland Deer! Deer leap softly over mossy logs and nibble sweet green leaves!",
    "frog": "Ribbit, ribbit! Green Frog! Frogs sit on round green lily pads and hop super high!",
    "duck": "Quack, quack! Mallard Duck! Ducks paddle webbed feet under the pond water looking for snacks!",
    "tractor": "Scrub, scrub, sparkle! Big Red Tractor! Giant bumpy tires pull plows and hay wagons across muddy fields!",
    "dump-truck": "Whoosh, all clean! Heavy Dump Truck! Dump trucks haul sand and gravel and tip their back beds high!",
    "fire-truck": "Shiny bright red! Helper Fire Engine! Fire engines carry tall ladders and big water hoses to help!",
    "trex": "Pop! Look who hatched—a friendly Green T-Rex! T-Rex walked on two strong back legs with tiny front arms!",
    "triceratops": "Pop! It's a gentle Blue Triceratops! Triceratops had three horns and a big frill, and munched green plants!",
    "brachiosaurus": "Pop! Amazing! A giant Brachiosaurus! Its super tall neck reached high treetop leaves like a giraffe!",
    "stegosaurus": "Pop! Yay! A happy Purple Stegosaurus with sunny yellow plates along its arched back!",
    "pterodactyl": "Pop! Whoosh! A flying Yellow Pterodactyl gliding smoothly through prehistoric skies!",
    "ankylosaurus": "Pop! Hooray! A strong Orange Ankylosaurus wearing a bumpy shell like a giant friendly turtle!"
}

def main():
    if not API_KEY:
        print("Set ELEVENLABS_API_KEY first to generate studio Gigi MP3s.")
        return
    os.makedirs("audio", exist_ok=True)
    generated = []
    for clip_id, text in CLIPS.items():
        out_fn = f"{clip_id}.mp3"
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{VOICE_ID}"
        resp = requests.post(
            url,
            headers={"xi-api-key": API_KEY, "Content-Type": "application/json"},
            json={
                "text": text,
                "model_id": "eleven_multilingual_v2",
                "voice_settings": {"stability": 0.65, "similarity_boost": 0.23, "speed": 0.97}
            },
            timeout=30
        )
        resp.raise_for_status()
        with open(os.path.join("audio", out_fn), "wb") as f:
            f.write(resp.content)
        generated.append(out_fn)
        print("Saved:", out_fn)

    with open("audio/manifest.json", "w", encoding="utf-8") as f:
        json.dump({"files": generated}, f, indent=2)
    print("Updated audio/manifest.json with", len(generated), "studio clips!")

if __name__ == "__main__":
    main()
